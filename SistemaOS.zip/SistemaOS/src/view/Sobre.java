package view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField; 

public class Sobre extends JDialog {
	private static final long serialVersionUID = 1L;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Sobre dialog = new Sobre();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				}	catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public Sobre() {
		getContentPane().setBackground(SystemColor.text);
		setModal(true);
		setTitle("Sobre");
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Sobre.class.getResource("/img/9071369_dumbbell_icon.png")));
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Target Assistencia");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(127, 11, 151, 26);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Autor: Felipe de Almeida Duarte");
		lblNewLabel_1.setFont(new Font("Showcard Gothic", Font.PLAIN, 11));
		lblNewLabel_1.setBounds(10, 59, 214, 14);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Sob a licença MIT");
		lblNewLabel_2.setBounds(301, 111, 112, 14);
		getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(Sobre.class.getResource("/img/mit-icon.png")));
		lblNewLabel_3.setBounds(285, 111, 128, 128);
		getContentPane().add(lblNewLabel_3);
		
		JLabel lblHalterUm = new JLabel("");
		lblHalterUm.setIcon(new ImageIcon(Sobre.class.getResource("/img/9071369_dumbbell_icon.png")));
		lblHalterUm.setBorder(null);
		lblHalterUm.setBounds(288, 0, 48, 48);
		getContentPane().add(lblHalterUm);
		
		JLabel lblHalterDois = new JLabel("");
		lblHalterDois.setIcon(new ImageIcon(Sobre.class.getResource("/img/9071369_dumbbell_icon.png")));
		lblHalterDois.setBorder(null);
		lblHalterDois.setBounds(69, 0, 48, 48);
		getContentPane().add(lblHalterDois);
		
		JLabel lblGithub = new JLabel("");
		lblGithub.setIcon(new ImageIcon(Sobre.class.getResource("/img/211904_social_github_icon.png")));
		lblGithub.setBorder(null);
		lblGithub.setBounds(10, 158, 48, 48);
		getContentPane().add(lblGithub);
		
		JLabel lblNewLabel_1_1 = new JLabel("Redes sociais:");
		lblNewLabel_1_1.setFont(new Font("Showcard Gothic", Font.PLAIN, 11));
		lblNewLabel_1_1.setBounds(10, 133, 91, 14);
		getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("felipea1");
		lblNewLabel_1_1_1.setFont(new Font("Franklin Gothic Medium Cond", Font.PLAIN, 17));
		lblNewLabel_1_1_1.setBounds(69, 173, 91, 20);
		getContentPane().add(lblNewLabel_1_1_1);
		
		JLabel lblInstagram = new JLabel("");
		lblInstagram.setIcon(new ImageIcon(Sobre.class.getResource("/img/104466_instagram_icon.png")));
		lblInstagram.setBorder(null);
		lblInstagram.setBounds(10, 213, 48, 48);
		getContentPane().add(lblInstagram);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("yFelpsz_");
		lblNewLabel_1_1_1_1.setFont(new Font("Franklin Gothic Medium Cond", Font.PLAIN, 17));
		lblNewLabel_1_1_1_1.setBounds(69, 230, 91, 20);
		getContentPane().add(lblNewLabel_1_1_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Versão alpha 1.0");
		lblNewLabel_1_2.setFont(new Font("Showcard Gothic", Font.PLAIN, 11));
		lblNewLabel_1_2.setBounds(10, 94, 104, 14);
		getContentPane().add(lblNewLabel_1_2);
	} //Fim do construtor
}//Fim do código
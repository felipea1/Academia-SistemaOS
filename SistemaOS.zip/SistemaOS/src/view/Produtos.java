package view;

import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import model.DAO;
import utils.Validador;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JScrollPane;
import javax.swing.JList;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Produtos extends JDialog {

	DAO dao = new DAO();
	private Connection con;
	private PreparedStatement pst;
	private ResultSet rs;

	private FileInputStream fis;
	private int tamanho;

	private boolean produtoCadastrado;

	private static final long serialVersionUID = 1L;
	private JTextField txtCodigoPr;
	private JTextField txtBarcode;
	private JTextField txtEstoque;
	private JTextField txtEstoqueMin;
	private JTextField txtValor;
	private JTextField txtLocal;
	private JButton btnAdicionar;
	private JButton btnEditar;
	private JButton btnExcluir;
	private JTextArea txtDescricao;
	private JLabel lblFoto;
	private JButton btnBuscar;
	private JButton btnCarregar;
	private JTextField txtUN;
	private JTextField txtNome;
	private JList listPR;
	private JScrollPane scrollPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Produtos dialog = new Produtos();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the dialog.
	 */
	public Produtos() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Produtos.class.getResource("/img/produtos.png")));
		setModal(true);
		setTitle("Produtos");
		setResizable(false);
		setBounds(100, 100, 656, 578);
		getContentPane().setLayout(null);

		scrollPane = new JScrollPane();
		scrollPane.setVisible(false);
		scrollPane.setBorder(null);
		scrollPane.setBounds(10, 102, 131, 32);
		getContentPane().add(scrollPane);

		listPR = new JList();
		listPR.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				buscarProdutoLista();
			}
		});
		scrollPane.setViewportView(listPR);

		JLabel lblCodigoPr = new JLabel("Código do produto:");
		lblCodigoPr.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblCodigoPr.setBounds(10, 11, 131, 14);
		getContentPane().add(lblCodigoPr);

		txtCodigoPr = new JTextField();
		txtCodigoPr.setEditable(false);
		txtCodigoPr.setBounds(10, 29, 131, 20);
		getContentPane().add(txtCodigoPr);
		txtCodigoPr.setDocument(new Validador(5));
		txtCodigoPr.setColumns(10);

		JLabel lblBarcode = new JLabel("Código de barras:");
		lblBarcode.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblBarcode.setBounds(10, 130, 116, 14);
		getContentPane().add(lblBarcode);

		txtBarcode = new JTextField();
		txtBarcode.setBounds(10, 155, 131, 20);
		getContentPane().add(txtBarcode);
		txtBarcode.setDocument(new Validador(20));
		txtBarcode.setColumns(10);

		JLabel lblDescricao = new JLabel("Descrição:");
		lblDescricao.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblDescricao.setBounds(377, 410, 68, 14);
		getContentPane().add(lblDescricao);

		txtDescricao = new JTextArea();
		txtDescricao.setBounds(456, 405, 174, 70);
		getContentPane().add(txtDescricao);

		JLabel lblFotoo = new JLabel("Foto:");
		lblFotoo.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblFotoo.setBounds(450, 59, 68, 14);
		getContentPane().add(lblFotoo);

		JLabel lblEstoque = new JLabel("Estoque:");
		lblEstoque.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblEstoque.setBounds(10, 186, 68, 14);
		getContentPane().add(lblEstoque);

		txtEstoque = new JTextField();
		txtEstoque.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				String caracteres = "0123456789.',";
				if (!caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtEstoque.setBounds(10, 211, 131, 20);
		getContentPane().add(txtEstoque);
		txtEstoque.setDocument(new Validador(20));
		txtEstoque.setColumns(10);

		JLabel lblEstoqueMin = new JLabel("Estoque mínimo:");
		lblEstoqueMin.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblEstoqueMin.setBounds(10, 242, 108, 14);
		getContentPane().add(lblEstoqueMin);

		txtEstoqueMin = new JTextField();
		txtEstoqueMin.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				String caracteres = "0123456789.',";
				if (!caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtEstoqueMin.setColumns(10);
		txtEstoqueMin.setBounds(10, 267, 131, 20);
		txtEstoqueMin.setDocument(new Validador(20));
		getContentPane().add(txtEstoqueMin);

		JLabel lblValor = new JLabel("Valor:");
		lblValor.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblValor.setBounds(10, 298, 68, 14);
		getContentPane().add(lblValor);

		txtValor = new JTextField();
		txtValor.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				String caracteres = "0123456789.',";
				if (!caracteres.contains(e.getKeyChar() + "")) {
					e.consume();
				}
			}
		});
		txtValor.setColumns(10);
		txtValor.setBounds(10, 323, 131, 20);
		txtValor.setDocument(new Validador(20));
		getContentPane().add(txtValor);

		JLabel lblUnidade = new JLabel("Unidade de medida:");
		lblUnidade.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblUnidade.setBounds(10, 410, 120, 14);
		getContentPane().add(lblUnidade);

		JLabel lblLocal = new JLabel("Local de armazenagem: ");
		lblLocal.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblLocal.setBounds(10, 354, 158, 14);
		getContentPane().add(lblLocal);

		txtLocal = new JTextField();
		txtLocal.setColumns(10);
		txtLocal.setBounds(10, 379, 131, 20);
		txtLocal.setDocument(new Validador(50));
		getContentPane().add(txtLocal);

		btnAdicionar = new JButton("");
		btnAdicionar.setEnabled(false);
		btnAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Adicionar();
			}
		});
		btnAdicionar.setToolTipText("Adicionar Produto");
		btnAdicionar.setIcon(new ImageIcon(Produtos.class.getResource("/img/adicionar.png")));
		btnAdicionar.setContentAreaFilled(false);
		btnAdicionar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnAdicionar.setBorder(null);
		btnAdicionar.setBounds(55, 470, 64, 64);
		getContentPane().add(btnAdicionar);

		btnEditar = new JButton("");
		btnEditar.setEnabled(false);
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editar();
			}
		});
		btnEditar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnEditar.setIcon(new ImageIcon(Produtos.class.getResource("/img/editar4.png")));
		btnEditar.setToolTipText("Editar");
		btnEditar.setContentAreaFilled(false);
		btnEditar.setBorder(null);
		btnEditar.setBounds(150, 470, 64, 64);
		getContentPane().add(btnEditar);

		btnExcluir = new JButton("");
		btnExcluir.setEnabled(false);
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				excluir();
			}
		});
		btnExcluir.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnExcluir.setIcon(new ImageIcon(Produtos.class.getResource("/img/excluir2.png")));
		btnExcluir.setToolTipText("Excluir");
		btnExcluir.setContentAreaFilled(false);
		btnExcluir.setBorder(null);
		btnExcluir.setBounds(250, 470, 64, 64);
		getContentPane().add(btnExcluir);

		JButton btnLimpar = new JButton("");
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LimparCampos();
			}
		});
		btnLimpar.setIcon(new ImageIcon(Produtos.class.getResource("/img/eraser.png")));
		btnLimpar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnLimpar.setToolTipText("Limpar campos");
		btnLimpar.setContentAreaFilled(false);
		btnLimpar.setBorder(null);
		btnLimpar.setBounds(345, 470, 64, 64);
		getContentPane().add(btnLimpar);

		btnBuscar = new JButton("");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BuscarCode();
				
			}			
		});
		btnBuscar.setIcon(new ImageIcon(Produtos.class.getResource("/img/pesquisar.png")));
		btnBuscar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnBuscar.setToolTipText("Excluir");
		btnBuscar.setContentAreaFilled(false);
		btnBuscar.setBorder(null);
		btnBuscar.setBounds(163, 143, 32, 32);
		getContentPane().add(btnBuscar);

		lblFoto = new JLabel("");
		lblFoto.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		lblFoto.setIcon(new ImageIcon(Produtos.class.getResource("/img/camera.png")));
		lblFoto.setBounds(350, 84, 256, 256);
		getContentPane().add(lblFoto);

		btnCarregar = new JButton("Carregar foto");
		btnCarregar.setEnabled(false);
		btnCarregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				carregarFoto();
			}
		});
		btnCarregar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnCarregar.setForeground(SystemColor.desktop);
		btnCarregar.setBounds(490, 346, 116, 23);
		getContentPane().add(btnCarregar);

		txtUN = new JTextField();
		txtUN.setBounds(10, 439, 130, 20);
		getContentPane().add(txtUN);
		txtUN.setColumns(10);

		JLabel lblNome = new JLabel("Nome");
		lblNome.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNome.setBounds(10, 60, 46, 14);
		getContentPane().add(lblNome);

		txtNome = new JTextField();
		txtNome.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				listarProdutos();
			}
		});
		txtNome.setColumns(10);
		txtNome.setBounds(10, 84, 131, 20);
		getContentPane().add(txtNome);
	} // Fim do construtor

	private void carregarFoto() {
		JFileChooser jfc = new JFileChooser();
		jfc.setDialogTitle("Selecionar arquivo");
		jfc.setFileFilter(new FileNameExtensionFilter("Arquivo de imagens(*.PNG,*.JPG,*.JPEG)", "png", "jpg", "jpeg"));
		int resultado = jfc.showOpenDialog(this);
		if (resultado == JFileChooser.APPROVE_OPTION) {
			try {
				fis = new FileInputStream(jfc.getSelectedFile());
				tamanho = (int) jfc.getSelectedFile().length();
				Image foto = ImageIO.read(jfc.getSelectedFile()).getScaledInstance(lblFoto.getWidth(),
						lblFoto.getHeight(), Image.SCALE_SMOOTH);
				lblFoto.setIcon(new ImageIcon(foto));
				lblFoto.updateUI();
				if (produtoCadastrado) {
					btnEditar.setEnabled(true);
					btnAdicionar.setEnabled(false);
				} else {
					btnEditar.setEnabled(false);
					btnAdicionar.setEnabled(true);
				}
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	private void BuscarCode() {
		if (txtBarcode.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Digite o código de barras do produto");
			txtBarcode.requestFocus();
		} else {
			String readCode = "select * from produtos where barcode = ?";
			try {
				con = dao.conectar();
				pst = con.prepareStatement(readCode);
				pst.setString(1, txtBarcode.getText());
				rs = pst.executeQuery();
				if (rs.next()) {
					txtCodigoPr.setText(rs.getString(1));
					txtBarcode.setText(rs.getString(2));
					txtDescricao.setText(rs.getString(3));
					Blob blob = (Blob) rs.getBlob(4);
					byte[] img = blob.getBytes(1, (int) blob.length());
					BufferedImage imagem = null;
					try {
						imagem = ImageIO.read(new ByteArrayInputStream(img));
					} catch (Exception e) {
						System.out.println(e);
					}
					ImageIcon icone = new ImageIcon(imagem);
					Icon foto = new ImageIcon(icone.getImage().getScaledInstance(lblFoto.getWidth(),
							lblFoto.getHeight(), Image.SCALE_SMOOTH));
					lblFoto.setIcon(foto);
					txtEstoque.setText(rs.getString(5));
					txtEstoqueMin.setText(rs.getString(6));
					txtValor.setText(rs.getString(7));
					txtUN.setText(rs.getString(8));
					txtLocal.setText(rs.getString(9));
					txtNome.setText(rs.getString(10));
					produtoCadastrado = true;
					btnBuscar.setEnabled(false);
					btnCarregar.setEnabled(true);
					btnExcluir.setEnabled(true);
				} else {
					JOptionPane.showMessageDialog(null, "Produto inexistente");
					produtoCadastrado = false;
					btnBuscar.setEnabled(false);
					txtBarcode.requestFocus();
					btnCarregar.setEnabled(true);
					txtUN.setText(null);
				}
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	private void listarProdutos() {
		DefaultListModel<String> modelo = new DefaultListModel<>();
		listPR.setModel(modelo);
		String readListaPr = "select * from produtos where nome like '" + txtNome.getText() + "%'" + "order by nome";
		try {
			con = dao.conectar();
			pst = con.prepareStatement(readListaPr);
			rs = pst.executeQuery();
			while(rs.next()) {
				scrollPane.setVisible(true);
				modelo.addElement(rs.getString(10));
				if (txtNome.getText().isEmpty()) {
					scrollPane.setVisible(false);
				}
			} 
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	private void buscarProdutoLista() {
		int linha = listPR.getSelectedIndex();
		if (linha >= 0) {
			String readListaCli = "select * from produtos where nome like '" + txtNome.getText() + "%'"	+ "order by nome limit " + (linha) + " , 1";
			try {
				con = dao.conectar();
				pst = con.prepareStatement(readListaCli);
				rs = pst.executeQuery();
				if (rs.next()) {
					scrollPane.setVisible(false);
					txtCodigoPr.setText(rs.getString(1));
					txtBarcode.setText(rs.getString(2));
					txtDescricao.setText(rs.getString(3));
					Blob blob = (Blob) rs.getBlob(4);
					byte[] img = blob.getBytes(1, (int) blob.length());
					BufferedImage imagem = null;
					try {
						imagem = ImageIO.read(new ByteArrayInputStream(img));
					} catch (Exception e) {
						System.out.println(e);
					}
					ImageIcon icone = new ImageIcon(imagem);
					Icon foto = new ImageIcon(icone.getImage().getScaledInstance(lblFoto.getWidth(),
							lblFoto.getHeight(), Image.SCALE_SMOOTH));
					lblFoto.setIcon(foto);
					txtEstoque.setText(rs.getString(5));
					txtEstoqueMin.setText(rs.getString(6));
					txtValor.setText(rs.getString(7));
					txtUN.setText(rs.getString(8));
					txtLocal.setText(rs.getString(9));
					txtNome.setText(rs.getString(10));
					produtoCadastrado = true;
					btnBuscar.setEnabled(false);
					btnCarregar.setEnabled(true);
					btnExcluir.setEnabled(true);
				} else {
					JOptionPane.showMessageDialog(null, "Produto inexistente");
					produtoCadastrado = false;
					btnBuscar.setEnabled(false);
					txtBarcode.requestFocus();
					btnCarregar.setEnabled(true);
					txtUN.setText(null);
				}
				con.close();
			} catch (Exception e) {
				System.out.println(e);
			} 
		} else {
			scrollPane.setVisible(false);
		}
	}

	private void LimparCampos() {
		txtCodigoPr.setText(null);
		txtBarcode.setText(null);
		txtEstoque.setText(null);
		txtEstoqueMin.setText(null);
		txtValor.setText(null);
		txtDescricao.setText(null);
		txtLocal.setText(null);
		txtUN.setText(null);
		txtNome.setText(null);
		lblFoto.setIcon(new ImageIcon(Produtos.class.getResource("/img/camera.png")));
		produtoCadastrado = false;
		btnCarregar.setEnabled(false);
		btnAdicionar.setEnabled(false);
		btnEditar.setEnabled(false);
		btnExcluir.setEnabled(false);
		btnBuscar.setEnabled(true);
		txtBarcode.requestFocus();
	}

	private void Adicionar() {
		if (txtBarcode.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o Código de barras do produto!");
			txtBarcode.requestFocus();
		} else if (txtEstoque.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o estoque do produto!");
			txtEstoque.requestFocus();
		} else if (txtEstoqueMin.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o estoque mínimo do produto!");
			txtEstoqueMin.requestFocus();
		} else if (txtValor.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o valor do produto!");
			txtValor.requestFocus();
		} else if (txtUN.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o tipo de produto!");
			txtUN.requestFocus();
		} else if (txtLocal.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o local do produto!");
			txtLocal.requestFocus();
		} else {
			String insert = "insert into produtos (barcode,descricao,foto,estoque,estoquemin,valor,unidade,localarm,nome) values (?,?,?,?,?,?,?,?,?)";
			try {
				con = dao.conectar();
				pst = con.prepareStatement(insert);
				pst.setString(1, txtBarcode.getText());
				pst.setString(2, txtDescricao.getText());
				pst.setBlob(3, fis, tamanho);
				pst.setString(4, txtEstoque.getText());
				pst.setString(5, txtEstoqueMin.getText());
				pst.setString(6, txtValor.getText());
				pst.setString(7, txtUN.getText());
				pst.setString(8, txtLocal.getText());
				pst.setString(9, txtNome.getText());
				int confirma = pst.executeUpdate();
				if (confirma == 1) {
					JOptionPane.showMessageDialog(null, "Produto cadastrado com sucesso!");
					LimparCampos();
					txtBarcode.requestFocus();
				} else {
					JOptionPane.showMessageDialog(null, "Erro! Produto não cadastrado.");
				}
				con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	private void editar() {
		if (txtNome.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o nome do produto!");
			txtNome.requestFocus();
		} else if (txtBarcode.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o Código de barras do produto!");
			txtBarcode.requestFocus();
		} else if (txtEstoque.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o estoque do produto!");
			txtEstoque.requestFocus();
		} else if (txtEstoqueMin.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o estoque mínimo do produto!");
			txtEstoqueMin.requestFocus();
		} else if (txtValor.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o valor do produto!");
			txtValor.requestFocus();
		} else if (txtUN.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o tipo de produto!");
			txtUN.requestFocus();
		} else if (txtLocal.getText().isEmpty()) {
			JOptionPane.showMessageDialog(null, "Preencha o local do produto!");
			txtLocal.requestFocus();
		} else {
			String update = "update produtos set barcode =?,descricao=?,foto=?,estoque=?,estoquemin=?,valor=?,unidade=?,localarm=?, nome=? where codigo=?";
			try {
				con = dao.conectar();
				pst = con.prepareStatement(update);
				pst.setString(1, txtBarcode.getText());
				pst.setString(2, txtDescricao.getText());
				pst.setBlob(3, fis, tamanho);
				pst.setString(4, txtEstoque.getText());
				pst.setString(5, txtEstoqueMin.getText());
				pst.setString(6, txtValor.getText());
				pst.setString(7, txtUN.getText());
				pst.setString(8, txtLocal.getText());
				pst.setString(9, txtNome.getText());
				pst.setString(10, txtCodigoPr.getText());
				int confirma = pst.executeUpdate();
				if (confirma == 1) {
					JOptionPane.showMessageDialog(null, "Dados do produto alterados com sucesso");
					LimparCampos();
				} else {
					JOptionPane.showMessageDialog(null, "Erro! Não foi possível alterar os dados do produto");
				}
				con.close();
			} catch (Exception e) {
				System.out.println(e);
			}

		}
	}

	private void excluir() {
		int confirmar = JOptionPane.showConfirmDialog(null, "Deseja mesmo excluir o produto?", "Atenção",
				JOptionPane.YES_NO_OPTION);
		if (confirmar == JOptionPane.YES_OPTION) {
			String delete = "delete from produtos where codigo=?";
			try {
				con = dao.conectar();
				pst = con.prepareStatement(delete);
				pst.setString(1, txtCodigoPr.getText());
				pst.executeUpdate();
				LimparCampos();
				JOptionPane.showMessageDialog(null, "Produto excluido!");
				con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}
} // Fim do código
